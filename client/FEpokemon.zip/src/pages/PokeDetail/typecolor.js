const color = [
  { name: "bug", color: "bg-bugGreen" },
  { name: "dragon", color: "bg-dragonBlue" },
  { name: "fairy", color: "bg-fairyPink" },
  { name: "fire", color: "bg-fireRed" },
  { name: "ghost", color: "bg-ghostDark" },
  { name: "ground", color: "bg-groundBrown" },
  { name: "normal", color: "bg-normalGrey" },
  { name: "psychic", color: "bg-psychicPurple" },
  { name: "steel", color: "bg-steelGrey" },
  { name: "dark", color: "bg-darkBlack" },
  { name: "electric", color: "bg-electricYellow" },
  { name: "fighting", color: "bg-fightingRed" },
  { name: "flying", color: "bg-flyingBlue" },
  { name: "grass", color: "bg-grassGreen" },
  { name: "ice", color: "bg-iceBlue" },
  { name: "poison", color: "bg-poisonPurple" },
  { name: "rock", color: "bg-rockRed" },
  { name: "water", color: "bg-waterBlue" },
];

export default color
