import Banner1 from "./banner1_phone.jpg"
import Banner2 from "./banner2_phone.jpg"
import Banner3 from "./banner3_phone.jpg"
import Banner1PC from "./banner1_PC.jpg"
import Banner2PC from "./Banner2_PC.jpg"
import Banner3PC from "./banner3_PC.jpg"

export { Banner1, Banner2, Banner3, Banner1PC, Banner2PC, Banner3PC }